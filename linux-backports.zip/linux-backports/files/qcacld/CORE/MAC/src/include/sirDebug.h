/*
 * Copyright (c) 2011-2012,2014 The Linux Foundation. All rights reserved.
 *
 * Previously licensed under the ISC license by Qualcomm Atheros, Inc.
 *
 *
 * Permission to use, copy, modify, and/or distribute this software for
 * any purpose with or without fee is hereby granted, provided that the
 * above copyright notice and this permission notice appear in all
 * copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL
 * WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE
 * AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL
 * DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
 * PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 * TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 */

/*
 * This file was originally distributed by Qualcomm Atheros, Inc.
 * under proprietary terms before Copyright ownership was assigned
 * to the Linux Foundation.
 */

/*
 *
 *
 * Author:      Sandesh Goel
 * Date:        02/25/02
 * History:-
 * Date            Modified by    Modification Information
 * --------------------------------------------------------------------
 *
 */

#ifndef __POL_DEBUG_H__
#define __POL_DEBUG_H__

#define LOGOFF  0
#define LOGP    1
#define LOGE    2
#define LOGW    3
#define LOG1    4
#define LOG2    5
#define LOG3    6
#define LOG4    7

#ifdef  WLAN_MDM_CODE_REDUCTION_OPT
#ifdef PE_DEBUG_LOGE
#define PELOGE(p) { p }
#else
#define PELOGE(p) { }
#endif

#ifdef PE_DEBUG_LOGW
#define PELOGW(p) { p }
#else
#define PELOGW(p) { }
#endif

#define PELOG1(p) { }
#define PELOG2(p) { }
#define PELOG3(p) { }
#define PELOG4(p) { }


#else /* WLAN_MDM_CODE_REDUCTION_OPT */

#ifdef PE_DEBUG_LOGE
#define PELOGE(p) { p }
#else
#define PELOGE(p) { }
#endif

#ifdef PE_DEBUG_LOGW
#define PELOGW(p) { p }
#else
#define PELOGW(p) { }
#endif

#ifdef PE_DEBUG_LOG1
#define PELOG1(p) { p }
#else
#define PELOG1(p) { }
#endif

#ifdef PE_DEBUG_LOG2
#define PELOG2(p) { p }
#else
#define PELOG2(p) { }
#endif

#ifdef PE_DEBUG_LOG3
#define PELOG3(p) { p }
#else
#define PELOG3(p) { }
#endif

#ifdef PE_DEBUG_LOG4
#define PELOG4(p) { p }
#else
#define PELOG4(p) { }
#endif

#endif /* WLAN_MDM_CODE_REDUCTION_OPT */

#define FL(x)    "%s: %d: "\
                 x, __func__, __LINE__

#define MAC_ADDR_ARRAY(a) (a)[0], (a)[1], (a)[2], (a)[3], (a)[4], (a)[5]
#define MAC_ADDRESS_STR "%02x:%02x:%02x:%02x:%02x:%02x"

#endif
